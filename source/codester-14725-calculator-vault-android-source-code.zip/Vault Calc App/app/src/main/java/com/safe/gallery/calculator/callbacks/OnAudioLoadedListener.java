package com.safe.gallery.calculator.callbacks;

import com.safe.gallery.calculator.model.AllAudioModel;

import java.util.ArrayList;

public interface OnAudioLoadedListener {
    void onAudiosLoaded(ArrayList<AllAudioModel> arrayList);
}
