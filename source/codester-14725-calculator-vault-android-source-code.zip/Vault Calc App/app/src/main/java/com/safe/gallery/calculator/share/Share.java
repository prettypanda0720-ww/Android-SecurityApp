package com.safe.gallery.calculator.share;

import java.io.File;
import java.util.ArrayList;

public class Share {

    public static ArrayList<File> al_my_photos_photo = new ArrayList<>();
    public static int pass;
}
