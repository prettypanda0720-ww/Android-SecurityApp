package com.safe.gallery.calculator;

import java.io.File;
import java.util.ArrayList;

public class Constant {


    public static String bannerId = "ca-app-pub-3940256099942544/6300978111";
    public static String interstitialId = "ca-app-pub-3940256099942544/1033173712";

}
