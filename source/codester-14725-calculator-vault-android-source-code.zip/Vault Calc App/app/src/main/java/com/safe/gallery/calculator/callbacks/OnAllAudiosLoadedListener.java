package com.safe.gallery.calculator.callbacks;

import com.safe.gallery.calculator.model.AllAudioModel;

import java.util.ArrayList;

public interface OnAllAudiosLoadedListener {
    void onAllAudiosLoaded(ArrayList<AllAudioModel> arrayList);
}
