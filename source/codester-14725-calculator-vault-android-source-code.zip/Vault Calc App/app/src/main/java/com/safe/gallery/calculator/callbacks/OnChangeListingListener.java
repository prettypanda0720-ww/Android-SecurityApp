package com.safe.gallery.calculator.callbacks;

public interface OnChangeListingListener {
    void onChangeListing(String str);
}
