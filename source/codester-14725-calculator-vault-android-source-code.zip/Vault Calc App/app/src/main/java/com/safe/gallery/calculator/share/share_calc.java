package com.safe.gallery.calculator.share;

import android.app.Activity;

public class share_calc {
    public static Boolean Delete = Boolean.valueOf(false);
    public static int Theme_Selected_no = 1;
    public static Activity Theme_Selection_Activity;
    public static Boolean flag_expand = Boolean.valueOf(false);
}
